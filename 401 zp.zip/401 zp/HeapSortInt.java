package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Random;

public class HeapSortInt {

    private static int iterationCount = 0;

    public static void start() {
        // Generate an array of 10 random integers
        int[] integers = new int[1000];
        try
        {
            FileReader fr=new FileReader("intData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				String x[]=s.split(",");
				for(int i=0;i<1000;i++)
				{
				    integers[i]=Integer.parseInt(x[i]);
				}
			}
        }catch(Exception e)
        {
            System.out.println(e);
        }

        // Display the original array
        System.out.println("Original Array: " + Arrays.toString(integers));

        // Sort the array using Heap Sort
        heapSort(integers);

        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(integers));

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static void heapSort(int[] arr) {
        buildMaxHeap(arr);

        for (int i = arr.length - 1; i > 0; i--) {
            swap(arr, 0, i);
            maxHeapify(arr, i, 0);
        }
    }

    private static void buildMaxHeap(int[] arr) {
        for (int i = arr.length / 2 - 1; i >= 0; i--) {
            maxHeapify(arr, arr.length, i);
        }
    }

    private static void maxHeapify(int[] arr, int heapSize, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        iterationCount++; // Count each comparison
        if (left < heapSize && arr[left] > arr[largest]) {
            largest = left;
        }

        iterationCount++; // Count each comparison
        if (right < heapSize && arr[right] > arr[largest]) {
            largest = right;
        }

        if (largest != i) {
            swap(arr, i, largest);
            maxHeapify(arr, heapSize, largest);
        }
    }

    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    private static int[] generateRandomIntegers(int count) {
        int[] integers = new int[count];
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            integers[i] = random.nextInt(100); // Generating random integers between 0 and 99
        }

        return integers;
    }
}
