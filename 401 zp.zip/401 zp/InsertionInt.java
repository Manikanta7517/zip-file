package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

public class InsertionInt {

    public static void start() {
        

        int[] inputList = new int[1000];
        
        try
        {
            FileReader fr=new FileReader("intData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				String x[]=s.split(",");
				for(int i=0;i<1000;i++)
				{
				    inputList[i]=Integer.parseInt(x[i]);
				}
			}
        }catch(Exception e)
        {
            System.out.println(e);
        }
        // Display the original list
        System.out.println("Original List: " + Arrays.toString(inputList));
        System.out.println("\nSorted List (Algorithm 1): " + Arrays.toString(insertionSort(inputList)));

    }

    // Insertion Sort
    private static int[] insertionSort(int[] arr) {
        int comparisons = 0;
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                comparisons++;
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
        System.out.println("Comparisons (Insertion Sort): " + comparisons);
        return arr;
    }


}
