package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;


public class InsertionDouble {

    public static void start() {
        

        double[] inputList = new double[1000];
        
        try
        {
            FileReader fr=new FileReader("doubleData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				String x[]=s.split(",");
				for(int i=0;i<1000;i++)
				{
				    inputList[i]=Double.parseDouble(x[i]);
				}
			}
        }catch(Exception e)
        {
            System.out.println(e);
        }
        // Display the original list
        System.out.println("Original List: " + Arrays.toString(inputList));
        System.out.println("\nSorted List: " + Arrays.toString(insertionSort(inputList)));

    }

    // Insertion Sort
    private static double[] insertionSort(double[] arr) {
        int comparisons = 0;
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            double key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                comparisons++;
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
        System.out.println("Comparisons (Insertion Sort): " + comparisons);
        return arr;
    }


}
