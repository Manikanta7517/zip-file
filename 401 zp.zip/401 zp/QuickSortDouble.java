package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

public class QuickSortDouble {

    private static int iterationCount = 0;

    public static void start() {
        // Generate an array of 10 random double values
        double[] doubles = new double[1000];
        
        try
        {
            FileReader fr=new FileReader("doubleData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				String x[]=s.split(",");
				for(int i=0;i<1000;i++)
				{
				    doubles[i]=Double.parseDouble(x[i]);
				}
			}
        }catch(Exception e)
        {
            System.out.println(e);
        }

        // Display the original array
        System.out.println("Original Array: " + Arrays.toString(doubles));

        // Sort the array using Quick Sort
        quickSort(doubles, 0, doubles.length - 1);

        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(doubles));

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static void quickSort(double[] arr, int low, int high) {
        if (low < high) {
            // Partition the array and get the pivot index
            int pivotIndex = partition(arr, low, high);

            // Recursively sort the subarrays
            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    private static int partition(double[] arr, int low, int high) {
        double pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            iterationCount++; // Count each comparison

            if (arr[j] <= pivot) {
                i++;

                // Swap arr[i] and arr[j]
                double temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // Swap arr[i+1] and arr[high] 
        
        double temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    
}
