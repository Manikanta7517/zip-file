package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;


public class BinarySearchInt {
	// Counter to keep track of the number of iterations
    private static int iterationCount = 0;
    
    // Method to initiate the binary search with an integer target value
    public static void start(int target) {
        // Generate a sorted array of 1000 integers from file
        int[] sortedArray = new int[1000];
        try
        {
            FileReader fr=new FileReader("intData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
            	// Read a line from the file and split it into an array of strings
				String s=br.readLine();
				String x[]=s.split(",");
				// Convert each string to an integer and populate the array
				for(int i=0;i<1000;i++)
				{
				    sortedArray[i]=Integer.parseInt(x[i]);
				}
			}
        }catch(Exception e)
        {
        // To Handle exceptions, if any
            System.out.println(e);
        }

        // Display the sorted array
        System.out.println("Array IS: " + arrayToString(sortedArray));
         Arrays.sort(sortedArray);
        System.out.println("Sorted Array: " + arrayToString(sortedArray));
        System.out.println("Target Value: " + target);

        int resultIndex = binarySearch(sortedArray, target);

        // Display the result
        if (resultIndex != -1) {
            System.out.println("Target found at index " + resultIndex);
        } else {
            System.out.println("Target not found in the array");
        }

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static int binarySearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        
        //Binary search loop
            while (left <= right) {
            iterationCount++; // Count each comparison

            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; // Target found, return the index
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; // Target not found
    }
    //Utility method to convert the array to string for display
    private static String arrayToString(int[] arr) {
        StringBuilder stringBuilder = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            stringBuilder.append(arr[i]);
            if (i < arr.length - 1) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
