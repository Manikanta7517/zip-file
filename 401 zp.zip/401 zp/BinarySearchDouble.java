package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

public class BinarySearchDouble {

	// Counter to keep track of the number of iterations
    private static int iterationCount = 0;
    
    // Method to initiate the binary search with a target value
    public static void start(double target) {
    	// Generate a sorted array of 1000 double values from a file
        double[] sortedArray = new double[1000];
        try
        {
            FileReader fr=new FileReader("doubleData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
            	// Read a line from the file and split it into an array of strings
				String s=br.readLine();
				String x[]=s.split(",");
				// Convert each string to a double and populate the array
				for(int i=0;i<1000;i++)
				{
				    sortedArray[i]=Double.parseDouble(x[i]);
				}
			}
        }catch(Exception e)
        {
        	//To Handle exceptions, if any
            System.out.println(e);
        }

        // Display the original and sorted arrays, as well as the target value
        System.out.println("Array Is : " + arrayToString(sortedArray));
         Arrays.sort(sortedArray);
        System.out.println("Sorted Array: " + arrayToString(sortedArray));
        System.out.println("Target Value: " + target);
        // Perform binary search and get the result index
        double resultIndex = binarySearch(sortedArray, target);

        // Display the result
        if (resultIndex != -1) {
            System.out.println("Target found at index " + resultIndex);
        } else {
            System.out.println("Target not found in the array");
        }

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }
    
    // Binary search algorithm to find the target in the sorted array
    private static int binarySearch(double[] arr, double target) {
        int left = 0;
        int right = arr.length - 1;
        System.out.println("right"+right);
        
     // Binary search loop
        while (left <= right) {
            iterationCount++; // Count each comparison

         // Calculate the middle index
            int mid = left + (right - left) / 2;

         // Check if the target is found at the middle index
            if (arr[mid] == target) {
                return mid; // Target found, return the index
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // Target not found
    }
    // Utility method to convert the array to a string for display
    private static String arrayToString(double[] arr) {
        StringBuilder stringBuilder = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            stringBuilder.append(arr[i]);
            if (i < arr.length - 1) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
