package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;


public class BubbleString {

    public static void start() {
        String[] strings={} ;
        try
        {
            FileReader fr=new FileReader("StringData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				strings=s.split(",");
			}
            
        }catch(Exception e)
        {
            System.out.println(e);
        }
        // Display the original list
        System.out.println("Original List: " + Arrays.toString(strings));
        System.out.println("\nSorted List (Algorithm 1): " + Arrays.toString(bubbleSort(strings)));
    }

    
    // Bubble Sort
    private static String[] bubbleSort(String[] arr) {
        int comparisons = 0;
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                comparisons++;
                if (arr[j].compareTo(arr[j + 1])>0 ) {
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        System.out.println("Comparisons (Bubble Sort): " + comparisons);
        return arr;
    }

}
