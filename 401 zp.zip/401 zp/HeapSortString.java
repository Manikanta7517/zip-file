package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Random;

public class HeapSortString {

    private static int iterationCount = 0;

    public static void start() {
        // Generate an array of 10 random strings
        String[] strings={} ;
        try
        {
            FileReader fr=new FileReader("StringData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				strings=s.split(",");
			}
            
        }catch(Exception e)
        {
            System.out.println(e);
        }

        // Display the original array
        System.out.println("Original Array: " + Arrays.toString(strings));

        // Sort the array using Heap Sort
        heapSort(strings);

        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(strings));

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static void heapSort(String[] arr) {
        buildMaxHeap(arr);

        for (int i = arr.length - 1; i > 0; i--) {
            swap(arr, 0, i);
            maxHeapify(arr, i, 0);
        }
    }

    private static void buildMaxHeap(String[] arr) {
        for (int i = arr.length / 2 - 1; i >= 0; i--) {
            maxHeapify(arr, arr.length, i);
        }
    }

    private static void maxHeapify(String[] arr, int heapSize, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        iterationCount++; // Count each comparison
        if (left < heapSize && arr[left].compareTo(arr[largest]) > 0) {
            largest = left;
        }

        iterationCount++; // Count each comparison
        if (right < heapSize && arr[right].compareTo(arr[largest]) > 0) {
            largest = right;
        }

        if (largest != i) {
            swap(arr, i, largest);
            maxHeapify(arr, heapSize, largest);
        }
    }

    private static void swap(String[] arr, int i, int j) {
        String temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    private static String[] generateRandomStrings(int count) {
        String[] strings = new String[count];
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            // Generate random strings of length 5
            strings[i] = getRandomString(5, random);
        }

        return strings;
    }

    private static String getRandomString(int length, Random random) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < length; i++) {
            stringBuilder.append(characters.charAt(random.nextInt(characters.length())));
        }

        return stringBuilder.toString();
    }
}
