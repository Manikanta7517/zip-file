package Project;
import java.util.Arrays;
import java.io.*;

public class QuickSortString {

    private static int iterationCount = 0;

    public static void start() {
        // Generate an array of 10 random strings
        String[] strings={} ;
        try
        {
            FileReader fr=new FileReader("StringData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				strings=s.split(",");
			}
            
        }catch(Exception e)
        {
            System.out.println(e);
        }

        // Display the original array
        System.out.println("Original Array: " + Arrays.toString(strings));

        // Sort the array using Quick Sort
        quickSort(strings, 0, strings.length - 1);

        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(strings));

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static void quickSort(String[] arr, int low, int high) {
        if (low < high) {
            // Partition the array and get the pivot index
            int pivotIndex = partition(arr, low, high);

            // Recursively sort the subarrays
            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    private static int partition(String[] arr, int low, int high) {
        String pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            iterationCount++; // Count each comparison

            // Compare strings using compareTo method
            if (arr[j].compareTo(pivot) <= 0) {
                i++;

                // Swap arr[i] and arr[j]
                String temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // Swap arr[i+1] and arr[high] (pivot)
        String temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    
}
