package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;

public class LinearSearchString {

    private static int iterationCount = 0;

    public static void start(String target) {
        // Generate an array of 10 random strings
        String[] strings={} ;
        try
        {
            FileReader fr=new FileReader("StringData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				strings=s.split(",");
			}
            
        }catch(Exception e)
        {
            System.out.println(e);
        }

        // Display the original array
        System.out.println("Original Array: " + arrayToString(strings));

        // Perform linear search for a random target string
        
        System.out.println("Target String: " + target);

        int resultIndex = linearSearch(strings, target);

        // Display the result
        if (resultIndex != -1) {
            System.out.println("Target found at index " + resultIndex);
        } else {
            System.out.println("Target not found in the array");
        }

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static int linearSearch(String[] arr, String target) {
        for (int i = 0; i < arr.length; i++) {
            iterationCount++; // Count each comparison

            if (arr[i].equals(target)) {
                return i; // Target found, return the index
            }
        }

        return -1; // Target not found
    }

    private static String[] generateRandomStrings(int count) {
        String[] strings = new String[count];
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            strings[i] = getRandomString(5, random);
        }

        return strings;
    }

    private static String getRandomString(int length, Random random) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < length; i++) {
            stringBuilder.append(characters.charAt(random.nextInt(characters.length())));
        }

        return stringBuilder.toString();
    }

    private static String arrayToString(String[] arr) {
        StringBuilder stringBuilder = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            stringBuilder.append("\"").append(arr[i]).append("\"");
            if (i < arr.length - 1) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
