package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

public class InsertionString {

    public static void start() {
        

        String[] strings={} ;
        
        try
        {
            FileReader fr=new FileReader("StringData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				strings=s.split(",");
			}
            
        }catch(Exception e)
        {
            System.out.println(e);
        }
        // Display the original list
        System.out.println("Original List: " + Arrays.toString(strings));
        System.out.println("\nSorted List (Algorithm 1): " + Arrays.toString(insertionSort(strings)));

    }

    // Insertion Sort
    private static String[] insertionSort(String[] arr) {
        int comparisons = 0;
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            String key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j].compareTo(key)>0) {
                comparisons++;
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
        System.out.println("Comparisons (Insertion Sort): " + comparisons);
        return arr;
    }


}
