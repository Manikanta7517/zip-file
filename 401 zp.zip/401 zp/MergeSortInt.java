package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Random;

public class MergeSortInt {

    private static int iterationCount = 0;

    public static void start() {
        // Generate an array of 10 random integers
        int[] integers = new int[1000];
        try
        {
            FileReader fr=new FileReader("intData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				String x[]=s.split(",");
				for(int i=0;i<1000;i++)
				{
				    integers[i]=Integer.parseInt(x[i]);
				}
			}
        }catch(Exception e)
        {
            System.out.println(e);
        }

        // Display the original array
        System.out.println("Original Array: " + Arrays.toString(integers));

        // Sort the array using Merge Sort
        mergeSort(integers);

        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(integers));

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static void mergeSort(int[] arr) {
        if (arr == null || arr.length <= 1) {
            return;
        }

        int[] temp = new int[arr.length];
        mergeSort(arr, temp, 0, arr.length - 1);
    }

    private static void mergeSort(int[] arr, int[] temp, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;

            // Recursively sort the two halves
            mergeSort(arr, temp, left, mid);
            mergeSort(arr, temp, mid + 1, right);

            // Merge the sorted halves
            merge(arr, temp, left, mid, right);
        }
    }

    private static void merge(int[] arr, int[] temp, int left, int mid, int right) {
        // Copy data to temporary arrays
        for (int i = left; i <= right; i++) {
            temp[i] = arr[i];
        }

        int i = left;
        int j = mid + 1;
        int k = left;

        // Merge the two halves
        while (i <= mid && j <= right) {
            iterationCount++; // Count each comparison

            if (temp[i] <= temp[j]) {
                arr[k] = temp[i];
                i++;
            } else {
                arr[k] = temp[j];
                j++;
            }
            k++;
        }

        // Copy the remaining elements of left subarray
        while (i <= mid) {
            arr[k] = temp[i];
            k++;
            i++;
        }

        // Copy the remaining elements of right subarray
        while (j <= right) {
            arr[k] = temp[j];
            k++;
            j++;
        }
    }

    private static int[] generateRandomIntegers(int count) {
        int[] integers = new int[count];
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            integers[i] = random.nextInt(100); // Generating random integers between 0 and 99
        }

        return integers;
    }
}
