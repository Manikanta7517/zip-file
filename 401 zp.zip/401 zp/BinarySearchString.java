package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Random;

public class BinarySearchString {
	// Counter to keep track of the number of iterations
    private static int iterationCount = 0;

 // Method to initiate the binary search with a target string
    public static void start(String target) {
        // Generate a sorted array of 10 strings from file
        String[] sortedStrings={} ;
        try
        {
            FileReader fr=new FileReader("StringData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				sortedStrings=s.split(",");
			}
            
        }catch(Exception e)
        {
            System.out.println(e);
        }

        // Display the sorted array
        System.out.println("Array IS: " + arrayToString(sortedStrings));

        // Perform binary search for a random target string
        
        System.out.println("Target String: " + target);

        int resultIndex = binarySearch(sortedStrings, target);

        // Display the result
        if (resultIndex != -1) {
            System.out.println("Target found at index " + resultIndex);
        } else {
            System.out.println("Target not found in the array");
        }

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }
    // Binary search algorithm to find the target in the sorted array of strings
    private static int binarySearch(String[] arr, String target) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            iterationCount++; // Count each comparison

            int mid = left + (right - left) / 2;

            int compareResult = arr[mid].compareTo(target);

            if (compareResult == 0) {
                return mid; // Target found, return the index
            } else if (compareResult < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; // Target not found
    }
    
    // Utility method to generate an array of sorted random strings
    private static String[] generateSortedRandomStrings(int count) {
        String[] sortedStrings = new String[count];
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            sortedStrings[i] = getRandomString(5, random);
        }

        Arrays.sort(sortedStrings);
        return sortedStrings;
    }
    // Utility method to generate a random string of a given length
    private static String getRandomString(int length, Random random) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < length; i++) {
            stringBuilder.append(characters.charAt(random.nextInt(characters.length())));
        }

        return stringBuilder.toString();
    }

    // Utility method to convert the array of strings to a string for display
    private static String arrayToString(String[] arr) {
        StringBuilder stringBuilder = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            stringBuilder.append("\"").append(arr[i]).append("\"");
            if (i < arr.length - 1) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
