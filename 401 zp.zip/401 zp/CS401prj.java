package Project;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

//Main class CS401prj implementing ActionListener interface
class CS401prj implements ActionListener
{
	Frame f;
	Button ta;
	MenuBar mb;
	Menu type,searching,simplesort,sort;
	MenuItem integer,doubles,str,ls,bs,sel,bub,insertion,quick,merge,heap;
        int i;
        String sele[]=new String[3];
        
     // Constructor for initializing the GUI components
	public CS401prj()
	{
        i=0;
		f=new Frame("Project");	
		ta=new Button("Show Result");
		f.add(ta);

		mb=new MenuBar();
		f.setMenuBar(mb);

		type=new Menu("Type");
		mb.add(type);
		searching=new Menu("Searching");
		mb.add(searching);
		simplesort=new Menu("SimpleSort");
		mb.add(simplesort);
		sort=new Menu("Sort");
		mb.add(sort);
		
		
		integer=new MenuItem("Integer",new MenuShortcut(KeyEvent.VK_I));
		type.add(integer);
		doubles=new MenuItem("Double",new MenuShortcut(KeyEvent.VK_D));
		type.add(doubles);
		str=new MenuItem("String",new MenuShortcut(KeyEvent.VK_S));
		type.add(str);
                
		ls=new MenuItem("Linear Search",new MenuShortcut(KeyEvent.VK_S));
		searching.add(ls);
		bs=new MenuItem("Binary Search",new MenuShortcut(KeyEvent.VK_N,true));
		searching.add(bs);
                
		
		insertion=new MenuItem("Insertion Sort");
		simplesort.add(insertion);        
		bub=new MenuItem("Bubble Sort",new MenuShortcut(KeyEvent.VK_B));
		simplesort.add(bub);
        sel=new MenuItem("Selection Sort");
        simplesort.add(sel);
		
        quick=new MenuItem("Quick Sort");
		sort.add(quick);
		
		merge=new MenuItem("Merge Sort",new MenuShortcut(KeyEvent.VK_B));
		sort.add(merge);
		
        heap=new MenuItem("Heap Sort");
        sort.add(heap);
                
        // Adding action listeners to menu items
		integer.addActionListener(this);
		doubles.addActionListener(this);
		str.addActionListener(this);
		
                ls.addActionListener(this);
		        bs.addActionListener(this);
		
                insertion.addActionListener(this);
                sel.addActionListener(this);
                bub.addActionListener(this);
                
                quick.addActionListener(this);
                merge.addActionListener(this);
                heap.addActionListener(this);
                ta.addActionListener(this);
                
                f.setLayout(new FlowLayout());

		f.setSize(400,400);
		f.setVisible(true);
	}
	
	// ActionPerformed method to handle button click and menu item selection events
	public void actionPerformed(ActionEvent ae)
	{
                System.out.println(ae.getActionCommand());
		 if(ae.getSource()==ta)
                 {
                     i=0;
                     Random random = new Random();
                    int target = random.nextInt(100);
                    double t1=random.nextDouble();
                    String t2 = getRandomString(5, random);
                    
    // Logic to determine which sorting or searching algorithm to call based on user selections
                     if(sele[0].equalsIgnoreCase("Integer") && sele[1].equalsIgnoreCase("Linear Search"))
                     {
                         LinearSearchInt.start(target);
                     }
                     else if(sele[0].equalsIgnoreCase("Double") && sele[1].equalsIgnoreCase("Linear Search"))
                     {
                         LinearSearchDouble.start(t1);
                     }
                     else if(sele[0].equalsIgnoreCase("String") && sele[1].equalsIgnoreCase("Linear Search"))
                     {
                         LinearSearchString.start(t2);
                     }
                     
                     if(sele[0].equalsIgnoreCase("Integer") && sele[2].equalsIgnoreCase("Binary Search"))
                     {
                         BinarySearchInt.start(target);
                     }
                     else if(sele[0].equalsIgnoreCase("Double") && sele[2].equalsIgnoreCase("Binary Search"))
                     {
                         BinarySearchDouble.start(t1);
                     }
                     else if(sele[0].equalsIgnoreCase("String") && sele[1].equalsIgnoreCase("Binary Search"))
                     {
                         BinarySearchString.start(t2);
                     }
                     
                     if(sele[0].equalsIgnoreCase("Integer") && sele[1].equalsIgnoreCase("Insertion Sort"))
                     {
                         InsertionInt.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Integer") && sele[1].equalsIgnoreCase("Bubble Sort"))
                     {
                         BubbleInt.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Integer") && sele[1].equalsIgnoreCase("Selection Sort"))
                     {
                         SelectionInt.start();
                     }
                     if(sele[0].equalsIgnoreCase("Double") && sele[1].equalsIgnoreCase("Insertion Sort"))
                     {
                         InsertionDouble.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Double") && sele[1].equalsIgnoreCase("Bubble Sort"))
                     {
                         BubbleDouble.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Double") && sele[1].equalsIgnoreCase("Selection Sort"))
                     {
                         SelectionDouble.start();
                     }
                     if(sele[0].equalsIgnoreCase("String") && sele[1].equalsIgnoreCase("Insertion Sort"))
                     {
                         InsertionString.start();
                     }
                     else if(sele[0].equalsIgnoreCase("String") && sele[1].equalsIgnoreCase("Bubble Sort"))
                     {
                         BubbleString.start();
                     }
                     else if(sele[0].equalsIgnoreCase("String") && sele[1].equalsIgnoreCase("Selection Sort"))
                     {
                         SelectionString.start();
                     }
                     if(sele[0].equalsIgnoreCase("Integer") && sele[2].equalsIgnoreCase("Quick Sort"))
                     {
                         QuickSortInt.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Integer") && sele[2].equalsIgnoreCase("Merger Sort"))
                     {
                         MergeSortInt.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Integer") && sele[2].equalsIgnoreCase("Heap Sort"))
                     {
                         HeapSortInt.start();
                     }
                     if(sele[0].equalsIgnoreCase("Double") && sele[2].equalsIgnoreCase("Quick Sort"))
                     {
                         QuickSortDouble.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Double") && sele[2].equalsIgnoreCase("Merge Sort"))
                     {
                         MergeSortDouble.start();
                     }
                     else if(sele[0].equalsIgnoreCase("Double") && sele[2].equalsIgnoreCase("Heap Sort"))
                     {
                         HeapSortDouble.start();
                     }
                     if(sele[0].equalsIgnoreCase("String") && sele[2].equalsIgnoreCase("Quick Sort"))
                     {
                         QuickSortString.start();
                     }
                     else if(sele[0].equalsIgnoreCase("String") && sele[2].equalsIgnoreCase("Merge Sort"))
                     {
                         MergeSortString.start();
                     }
                     else if(sele[0].equalsIgnoreCase("String") && sele[2].equalsIgnoreCase("Heap Sort"))
                     {
                         QuickSortString.start();
                     }
                 }
                 else
                 {
                     sele[i]=ae.getActionCommand();
                     i++;
                 }
			
	}
	
	// Main method to create an instance of the CS401prj class
	public static void main(String args[])
	{	
		new CS401prj();
	} 
	    // Utility method to generate a random string of a specified length
        private static String getRandomString(int length, Random random) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < length; i++) {
            stringBuilder.append(characters.charAt(random.nextInt(characters.length())));
        }

        return stringBuilder.toString();
    }

}