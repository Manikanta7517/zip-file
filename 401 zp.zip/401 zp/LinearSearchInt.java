/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;

public class LinearSearchInt {

    private static int iterationCount = 0;

    public static void start(int target) {
        // Generate an array of 10 random integers
        int[] integers = new int[1000];
        
        try
        {
            FileReader fr=new FileReader("intData.txt");
            BufferedReader br=new BufferedReader(fr);
            String s=br.readLine();
            String x[]=s.split(",");
            for(int i=0;i<1000;i++)
            {
                integers[i]=Integer.parseInt(x[i]);
            }
        }catch(Exception e)
        {
            System.out.println(e);
        }
        // Display the original array
        System.out.println("Original Array: " + arrayToString(integers));

        // Perform linear search for a random target value
        
        System.out.println("Target Value: " + target);

        int resultIndex = linearSearch(integers, target);

        // Display the result
        if (resultIndex != -1) {
            System.out.println("Target found at index " + resultIndex);
        } else {
            System.out.println("Target not found in the array");
        }

        // Display the number of iterations
        System.out.println("Number of Iterations: " + iterationCount);
    }

    private static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            iterationCount++; // Count each comparison

            if (arr[i] == target) {
                return i; // Target found, return the index
            }
        }

        return -1; // Target not found
    }

    private static int[] generateRandomIntegers(int count) {
        int[] integers = new int[count];
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            integers[i] = random.nextInt(100); // Generating random integers between 0 and 99
        }

        return integers;
    }

    private static String arrayToString(int[] arr) {
        StringBuilder stringBuilder = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            stringBuilder.append(arr[i]);
            if (i < arr.length - 1) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
