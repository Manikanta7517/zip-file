package Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;


public class BubbleDouble {
 
	// Method to start the Bubble Sort algorithm for an array of double values
    public static void start() {
    	// Initialize an array to store double values
        double[] inputList = new double[1000];
        
        try
        {
        	// Read double values from a file and populate the array
            FileReader fr=new FileReader("doubleData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				String x[]=s.split(",");
				for(int i=0;i<1000;i++)
				{
				    inputList[i]=Double.parseDouble(x[i]);
				}
			}
        }catch(Exception e)
        {
        	// To Handle exceptions, if any
            System.out.println(e);
        }
        // Display the original list
        System.out.println("Original List: " + Arrays.toString(inputList));
        System.out.println("\nSorted List (Algorithm 1): " + Arrays.toString(bubbleSort(inputList)));
    }

    
    // Bubble Sort algorithm
    private static double[] bubbleSort(double[] arr) {
        int comparisons = 0;
        int n = arr.length;
        
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                comparisons++;
                if (arr[j] > arr[j + 1]) {
                    double temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        // Display the number of comparisons
        System.out.println("Comparisons (Bubble Sort): " + comparisons);
        return arr;
    }

}
