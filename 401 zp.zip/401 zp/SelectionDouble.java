package Project;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;


public class SelectionDouble {

    public static void start() {
        

        double[] inputList = new double[1000];
        
        try
        {
            FileReader fr=new FileReader("doubleData.txt");
            try (BufferedReader br = new BufferedReader(fr)) {
				String s=br.readLine();
				String x[]=s.split(",");
				for(int i=0;i<1000;i++)
				{
				    inputList[i]=Double.parseDouble(x[i]);
				}
			}
        }catch(Exception e)
        {
            System.out.println(e);
        }
        // Display the original list
        System.out.println("Original List: " + Arrays.toString(inputList));
        System.out.println("\nSorted List (Algorithm 1): " + Arrays.toString(selectionSort(inputList)));  
    } 

    // Selection Sort
    private static double[] selectionSort(double[] arr) {
        int comparisons = 0;
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                comparisons++;
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            double temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
        System.out.println("Comparisons (Selection Sort): " + comparisons);
        return arr;
    }
}
